# from https://itnext.io/step-by-step-building-and-publishing-an-npm-typescript-package-44fe7164964c

# IMPORTANT
git checkout main

npm version patch
npm version minor
npm version major
npm publish --access=public