declare global {
    interface Window {
        TonAccess: object;
    }
}
export {};
